"""Application-specific installer modules"""
