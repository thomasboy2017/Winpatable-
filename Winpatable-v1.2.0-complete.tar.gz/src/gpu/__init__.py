"""GPU driver detection and management modules"""
