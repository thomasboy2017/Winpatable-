"""Wine and Proton configuration modules"""
