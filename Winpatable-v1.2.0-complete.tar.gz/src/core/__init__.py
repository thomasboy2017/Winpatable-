"""Core modules for system detection and compatibility checks"""
