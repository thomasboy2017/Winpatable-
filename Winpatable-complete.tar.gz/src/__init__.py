"""
Winpatable - Windows Compatibility Layer for Linux
"""

__version__ = "1.0.0"
__author__ = "Winpatable Contributors"
__license__ = "MIT"
