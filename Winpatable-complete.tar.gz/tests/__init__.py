"""Test suite initialization"""
